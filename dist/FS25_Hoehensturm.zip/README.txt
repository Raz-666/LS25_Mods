HÖHENSTURM — INVERSION COASTER (FS25)

PC ONLY. This mod requires CoasterRoll.lua; consoles are not supported.
For multiplayer, the server and every joining PC player must have the same mod.

INSTALL
1. Copy FS25_Hoehensturm.zip to the Farming Simulator 25 mods folder.
2. Enable it in the savegame mod list.
3. In the construction menu, place Höhensturm — Inversion Coaster.
   It is one large installation; allow approximately 180 x 370 m of clear ground.
4. At the station's train marker, rent the train and enter the front-left driver seat.
5. Tap accelerate to dispatch. Once the car moves, Lua locks it into an automatic
   full lap back to the station; braking, reversing, and all rider exits stay
   disabled en route. Wait for the full stop before leaving. Three passengers
   can ride in the same 2 x 2 car.

RIDE SPECIFICATIONS
- Track elevation: 2.5 m to about 58 m (over 55 m of vertical difference)
- Two full vertical loops plus a rising 1.5-turn spiral
- Manual dispatch; automatic full-lap return at up to 120 km/h
- Four total seats: one driver and three passengers
- A glass-vaulted station, cyan/violet LED tunnels at both loops and the rising spiral
- Original synthesized motor, fast whine, rail-air, dispatch-start and stop sounds
- Multiplayer co-riding uses the native FS25 passenger-seat system

MULTIPLAYER SAFETY
- Riders can exit individually after the train stops; no driver action is needed.
- A disconnected passenger is cleaned up through FS25's native seat/player cleanup.
- If the driver disconnects mid-lap, the coaster reasserts its station target and continues.
- If the host/server session itself ends, FS25 ends the whole multiplayer session.

The trainSystem spline handles movement and network updates. The Lua script
adds a closed rotation-minimising frame so the vehicle follows the track's roll
through both inversions and returns smoothly to upright at the station. It also
locks the locomotive and all rider exits for the duration of each dispatched lap.
